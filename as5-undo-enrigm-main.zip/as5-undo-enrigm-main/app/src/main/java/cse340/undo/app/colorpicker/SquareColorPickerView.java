package cse340.undo.app.colorpicker;

import android.annotation.SuppressLint;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.util.AttributeSet;
import android.view.MotionEvent;


/**
 * This is a subclass of AbstractColorPickerView, that is, this View implements a ColorPicker.
 *
 * There are several class fields, enums, callback classes, and helper functions which have
 * been implemented for you.
 *
 * PLEASE READ AbstractColorPickerView.java to learn about these.
 */


public class SquareColorPickerView extends ColorPickerView {

    /**
     * Update the local model (color) for this colorpicker view
     *
     * @param x The x location that the user selected
     * @param y The y location that the user selected
     */
    protected void updateModel(float x, float y) {
        mCurrentPickerColor = getColor(x, y);
    }

    /* ********************************************************************************************** *
     *                               <End of model declarations />
     * ********************************************************************************************** */

    /** The number of boxes horizontally in the color picker */
    private static final int BOXES_WIDTH = 3;

    /** The number of boxes vertically in the color picker */
    private static final int BOXES_HEIGHT = 3;

    /** the paint brushes for each box */
    private static Paint mBrushes[][];

    /** The paint brush for around the whole interactor */
    private static Paint mBorderPaint;

    /** dimension of each box */
    float mWidth;
    float mHeight;



    /* ********************************************************************************************** *
     *                               <End of other fields and constants declarations />
     * ********************************************************************************************** */

    /**
     *
     * Constructor of the ColorPicker View
     * @param context The Context the view is running in, through which it can access the current theme, resources, etc.
     * @param attrs The attributes of the XML tag that is inflating the view. This value may be null.
     */
    public SquareColorPickerView(Context context, AttributeSet attrs) {
        super(context, attrs);

        mBrushes = new Paint[BOXES_HEIGHT][BOXES_HEIGHT];
        int[][] colors = {
                {Color.rgb(0, 0, 0), Color.rgb(128, 128, 128), Color.rgb(225, 225, 225)},
                {Color.rgb(255, 0, 0), Color.rgb(0, 255, 0), Color.rgb(0, 0, 255)},
                {Color.rgb(255, 255, 0), Color.rgb(0, 255, 255), Color.rgb(255, 0, 255)}};

        for (int row = 0; row < mBrushes.length; row++) {
            for (int col = 0; col < mBrushes[row].length; col++) {
                mBrushes[row][col] = new Paint();
                mBrushes[row][col].setColor(colors[row][col]);
                mBrushes[row][col].setStyle(Paint.Style.FILL_AND_STROKE);
            }
        }

        mBorderPaint = new Paint();
        mBorderPaint.setStyle(Paint.Style.STROKE);
        mBorderPaint.setStrokeWidth(3);

        setPickerColor(mBrushes[BOXES_HEIGHT / 2][BOXES_WIDTH / 2].getColor());

    }
    /**
     * Called when this view should assign a size and position to all of its children.
     * @param changed This is a new size or position for this view
     * @param left Left position, relative to parent
     * @param top Top position, relative to parent
     * @param right Right position, relative to parent
     * @param bottom Bottom position, relative to parent
     */
    public void onLayout(boolean changed, int left, int top, int right, int bottom) {
        super.onLayout(changed, left, top, right, bottom);

        mWidth = right - left;
        mHeight = bottom - top;
    }

    /**
     * Calculate the essential geometry given an event.
     *
     * @param event Motion event to compute geometry for, most likely a touch.
     * @return EssentialGeometry value.
     */
    @Override
    protected EssentialGeometry essentialGeometry(MotionEvent event) {
        float x = event.getX();
        float y = event.getY();

        if (x > 0 && x < getWidth() && y > 0 && y < getHeight()) {
            return EssentialGeometry.INSIDE;
        } else {
            return EssentialGeometry.OUTSIDE;
        }
    }

    /**
     * Draw the ColorPicker on the Canvas
     * @param canvas the canvas that is drawn upon
     */
    @SuppressLint("DrawAllocation")
    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);

        int stroke = (int) mBorderPaint.getStrokeWidth();
        canvas.drawRect(0, 0, getWidth()-stroke, getHeight()-stroke, mBorderPaint);

        float boxwidth = getWidth() / BOXES_WIDTH;
        float boxheight = getHeight() / BOXES_HEIGHT;

        float x = 0;
        float y = 0;
        for (int row = 0; row < mBrushes.length; row++) {
            x = 0;
            for (int col = 0; col < mBrushes[row].length; col++) {
                canvas.drawRect(x, y, x + boxwidth, y + boxheight, mBrushes[row][col]);
                x += boxwidth;
            }
            y += boxheight;
        }
    }


    /* ****************************************************************************************** *
     *                               <Helper Functions />
     * ****************************************************************************************** */

    private int getColor(float x, float y) {

        float boxwidth = getWidth() / BOXES_WIDTH;
        float boxheight = getHeight() / BOXES_HEIGHT;

        int row = (int) Math.floor(y / boxheight);
        int col = (int) Math.floor(x / boxwidth);

        return mBrushes[row][col].getColor();
    }
}
