package cse340.undo.actions;

import android.graphics.Paint;
import android.support.annotation.NonNull;

import cse340.undo.R;
import cse340.undo.actions.AbstractReversibleAction;
import cse340.undo.app.DrawingView;
import cse340.undo.app.ReversibleDrawingActivity;

/**
 * Reversible action which changes the thickness of the DrawingView's paint.
 */
public class ChangeThicknessAction extends AbstractReversibleAction {
    /** The thickness that this action changes the current paint to. */
    private final int mThickness;

    /** The thickness that this action changes the current paint from. */
    private float mPrev;

    /**
     * Creates an action that changes the paint thickness.
     *
     * @param thickness New thickness for DrawingView paint.
     * @throws IllegalArgumentException if thickness not positive.
     */
    public ChangeThicknessAction(int thickness) {
        if (thickness < 0) {
            String error =
                    ReversibleDrawingActivity.resources.getString(R.string.thickness_exception,
                    thickness);
            throw new IllegalArgumentException(error);
        }
        this.mThickness = thickness;
    }

    /** @inheritDoc */
    @Override
    public void doAction(DrawingView view) {
        super.doAction(view);
        // TODO: update the thickness in the view
        // TODO: store any information you'll need to undo this later
        // TODO: don't store any information you won't need
        Paint p = view.getCurrentPaint();
        mPrev = p.getStrokeWidth();
        p.setStrokeWidth(mThickness);
    }

    /** @inheritDoc */
    @Override
    public void undoAction(DrawingView view) {
        super.undoAction(view);
        // TODO: update the thickness in the view
        Paint p = view.getCurrentPaint();
        p.setStrokeWidth(mPrev);
    }

    /** @inheritDoc */
    @NonNull
    @Override
    public String toString() {
        return ReversibleDrawingActivity.resources.getString(R.string.change_thickness, mThickness);
    }
}
