package cse340.undo.app.colorpicker;

import android.annotation.SuppressLint;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.PointF;
import android.graphics.Shader;
import android.support.annotation.ColorInt;
import android.support.v4.graphics.ColorUtils;
import android.util.AttributeSet;
import android.view.MotionEvent;



import cse340.undo.R;

// Thanks to Ashlin D (21sp) for allowing us to use their solution

/**
 * This is a subclass of AbstractColorPickerView, that is, this View implements a ColorPicker.
 *
 * There are several class fields, enums, callback classes, and helper functions which have
 * been implemented for you.
 *
 * PLEASE READ AbstractColorPickerView.java to learn about these.
 */
public class ValueColorPickerView extends ColorPickerView {

    /**
     * Update the local model (color) for this colorpicker view
     *
     * @param x The x location that the user selected
     * @param y The y location that the user selected
     */
    protected void updateModel(float x, float y) {
        // TODO implement this
        if (picking == Picking.NOTHING) picking = inLightness(x, y) ? Picking.LIGHTNESS : Picking.HUE;
        if (picking == Picking.LIGHTNESS) {
            lightness = getTouchProgress(x);
        } else {
            angle = getTouchAngle(x, y);
        }
        mCurrentPickerColor = getColor();
    }

    @Override
    public void setPickerColor(@ColorInt int newPickerColor) {
        lightness = getLightnessFromColor(newPickerColor);
        angle = getAngleFromColor(newPickerColor);
        super.setPickerColor(newPickerColor);
    }

    /* ********************************************************************************************** *
     *                               <End of model declarations />
     * ********************************************************************************************** */

    /* ********************************************************************************************** *
     * TODO Create variables you might need
     * You may create any constants you wish here.                                                     *
     * You may also create any fields you want, that are not necessary for the state but allow         *
     * for better optimized or cleaner code                                                             *
     * ********************************************************************************************** */

    private float angle;
    private float lightness;
    // Whether with this touch we're picking lightness or not
    private enum Picking { LIGHTNESS, HUE, NOTHING }
    private Picking picking = Picking.NOTHING;
    private float lightnessSliderTop;
    private float lightnessSliderBottom;
    private float lightnessSliderLeft;
    private float lightnessSliderRight;
    private final Paint thumbPaint, circlePaint, gradientPaint;
    private float mRadius, mThumbRadius, mCenterX, mCenterY, mCenterCircleRadius;
    protected static final float RADIUS_TO_THUMB_RATIO = 0.085f;
    /* ********************************************************************************************** *
     *                               <End of other fields and constants declarations />
     * ********************************************************************************************** */

    /**
     *
     * Constructor of the ColorPicker View
     * @param context The Context the view is running in, through which it can access the current theme, resources, etc.
     * @param attrs The attributes of the XML tag that is inflating the view. This value may be null.
     */
    public ValueColorPickerView(Context context, AttributeSet attrs) {
        super(context, attrs);
        setImageResource(R.drawable.color_wheel);
        thumbPaint = new Paint();
        thumbPaint.setColor(Color.WHITE);
        circlePaint = new Paint();
        circlePaint.setColor(Color.WHITE);
        gradientPaint = new Paint();
        angle = 0;
        lightness = 1;
    }
    /**
     * Called when this view should assign a size and position to all of its children.
     * @param changed This is a new size or position for this view
     * @param left Left position, relative to parent
     * @param top Top position, relative to parent
     * @param right Right position, relative to parent
     * @param bottom Bottom position, relative to parent
     */
    public void onLayout(boolean changed, int left, int top, int right, int bottom) {
        super.onLayout(changed, left, top, right, bottom);

        // TODO: calculate mRadius, mCenterX, and mCenterY based View dimensions
        // Hint: the ColorPicker view is not a square, base it off the min of the width and height
        int width = right - left;
        int height = bottom - top;
        int size = Math.min(height, width);
        mRadius = (float) size / 2;
        mCenterX = (float) width / 2;
        mCenterY = (float) height / 2;
        mThumbRadius = RADIUS_TO_THUMB_RATIO * mRadius;
        mCenterCircleRadius = mRadius - mThumbRadius * 2;

        // Set the dimensions for the lightness picker. Should be the size of thumb radius and in
        // the center.
        lightnessSliderTop = mCenterY - mThumbRadius;
        lightnessSliderBottom = mCenterY + mThumbRadius;
        lightnessSliderLeft = mCenterX - mCenterCircleRadius + mThumbRadius * 2;
        lightnessSliderRight = mCenterX + mCenterCircleRadius - mThumbRadius * 2;
    }

    /**
     * Calculate the essential geometry given an event.
     *
     * @param event Motion event to compute geometry for, most likely a touch.
     * @return EssentialGeometry value.
     */
    @Override
    protected EssentialGeometry essentialGeometry(MotionEvent event) {
        // TODO: compute the geometry for the given event

        // Please check if a touch event is inside the color picker circle
        // Calculate distance from center
        double dist = Math.sqrt(Math.pow(event.getX() - mCenterX, 2)
                + Math.pow(event.getY() - mCenterY, 2));
        if (dist <= mRadius) {
            return EssentialGeometry.INSIDE;
        } else {
            return EssentialGeometry.OUTSIDE;
        }
    }

    /**
     * Draw the ColorPicker on the Canvas
     * @param canvas the canvas that is drawn upon
     */
    @SuppressLint("DrawAllocation")
    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        // If we're at the start, ensure that we're not picking from any sub-slider
        if (mState == State.START) {
            picking = Picking.NOTHING;
        }

        // Set the thumb transparency
        if (picking == Picking.HUE) {
            thumbPaint.setAlpha(127);
        } else {
            thumbPaint.setAlpha(255);
        }
        // Draw the hue thumb. It needs to be on a track, one radius away from the edge.
        PointF trackPoint = getTrackPointFromAngle(angle);
        canvas.drawCircle(trackPoint.x, trackPoint.y, mThumbRadius, thumbPaint);

        // Draw the inner circle
        circlePaint.setColor(mCurrentPickerColor);
        canvas.drawCircle(mCenterX, mCenterY, mCenterCircleRadius, circlePaint);

        // Draw the lighting track
        // Unfortunately, the colors of a gradient can only be created in the constructor.
        gradientPaint.setShader(new LinearGradient(
                lightnessSliderLeft, 0, lightnessSliderRight, 0,
                Color.BLACK, getHue(), Shader.TileMode.MIRROR));
        canvas.drawRect(lightnessSliderLeft, lightnessSliderTop,
                lightnessSliderRight, lightnessSliderBottom, gradientPaint);

        // Draw the lightness thumb
        if (picking == Picking.LIGHTNESS) {
            thumbPaint.setAlpha(127);
        } else {
            thumbPaint.setAlpha(255);
        }
        PointF lightPoint = getLightnessPointFromProgress(lightness);
        canvas.drawCircle(lightPoint.x, lightPoint.y, mThumbRadius, thumbPaint);

    }


    /* ****************************************************************************************** *
     *                               <Helper Functions />
     * ****************************************************************************************** */

    private int getColor() {
        float hue = ((float) Math.toDegrees(angle) + 360 + 90) % 360;
        return Color.HSVToColor(new float[]{ hue, 1f, lightness });
    }

    private int getHue() {
        float hue = ((float) Math.toDegrees(angle) + 360 + 90) % 360;
        return Color.HSVToColor(new float[]{ hue, 1f, 1f });
    }

    private boolean inLightness(float touchX, float touchY) {
        return touchX > lightnessSliderLeft && touchX < lightnessSliderRight
                && touchY > lightnessSliderTop && touchY < lightnessSliderBottom;
    }

    private float getTouchProgress(float touchX) {
        // lerp
        float length = lightnessSliderRight - lightnessSliderLeft;
        float progress = touchX - lightnessSliderLeft;
        // Cap between 0 and 1
        return Math.max(0f, Math.min(1f, progress / length));
    }

    private float getTouchAngle(float touchX, float touchY) {
        // NOTE: This function REQUIRES that you properly use mCenterX, mCenterY, etc.

        // Assumes (for cardinal directions on the color wheel):
        // [ E => 0, South => Pi/2, W => -Pi, N => -Pi/2 ]

        return (float) Math.atan2(touchY - mCenterY, touchX - mCenterX);
    }
    private PointF getTrackPointFromAngle(float angle) {
        return new PointF(
                (mRadius - mThumbRadius) * (float) Math.cos(angle) + mCenterX,
                (mRadius - mThumbRadius) * (float) Math.sin(angle) + mCenterY);
    }
    private PointF getLightnessPointFromProgress(float progress) {
        return new PointF(
                lightnessSliderLeft + progress * (lightnessSliderRight - lightnessSliderLeft),
                lightnessSliderTop + (lightnessSliderBottom - lightnessSliderTop) / 2f
        );
    }
    public static float getAngleFromColor(int color) {
        float[] HSL = new float[3];
        ColorUtils.colorToHSL(color, HSL);
        return (float) Math.toRadians(HSL[0] - 90f);
    }
    public static float getLightnessFromColor(int color) {
        float[] HSV = new float[3];
        int r = Color.red(color);
        int b = Color.blue(color);
        int g = Color.green(color);
        Color.RGBToHSV(r, g, b, HSV);
        return (float) HSV[2];
    }
}
