package cse340.undo.app.colorpicker;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Point;
import android.support.annotation.ColorInt;
import android.support.v4.graphics.ColorUtils;
import android.util.AttributeSet;
import android.view.MotionEvent;

import cse340.undo.R;

/**
 * This is a subclass of AbstractColorPickerView, that is, this View implements a ColorPicker.
 *
 * There are several class fields, enums, callback classes, and helper functions which have
 * been implemented for you.
 *
 * PLEASE READ AbstractColorPickerView.java to learn about these.
 */
public class CircleColorPickerView extends ColorPickerView {

    /**
     * Update the local model (color) for this colorpicker view
     *
     * @param x The x location that the user selected
     * @param y The y location that the user selected
     */
    protected void updateModel(float x, float y) {
        mCurrentPickerColor = getColorFromAngle(getTouchAngle(x, y));
    }

/* ********************************************************************************************** *
 *                               <End of model declarations />
 * ********************************************************************************************** */

    /** Helper fields for keeping track of view geometry. */
    protected float mCenterX, mCenterY, mRadius;

    /** Ratio between radius of the thumb handle and mRadius, the radius of the wheel. */
    protected static final float RADIUS_TO_THUMB_RATIO = 0.085f;

    private float mCenterCircleRadius, mThumbRadius;
    private final Paint mThumbPaintStart, mThumbPaintInside;
    private final Paint mCenterCirclePaint;

/* ********************************************************************************************** *
 *                               <End of other fields and constants declarations />
 * ********************************************************************************************** */

    /**
     * Constructor of the ColorPicker View
     * @param context The Context the view is running in, through which it can access the current theme, resources, etc.
     * @param attrs The attributes of the XML tag that is inflating the view. This value may be null.
     */
    public CircleColorPickerView(Context context, AttributeSet attrs) {
        super(context, attrs);
        setImageResource(R.drawable.color_wheel);

        mThumbPaintStart = new Paint();
        mThumbPaintStart.setColor(Color.WHITE);
        mThumbPaintStart.setAlpha(255);

        mThumbPaintInside = new Paint();
        mThumbPaintInside.setColor(Color.WHITE);
        mThumbPaintInside.setAlpha((int) (0.5f * 255));

        mCenterCirclePaint = new Paint();
    }

    /**
     * Draw the ColorPicker on the Canvas
     * @param canvas the canvas that is drawn upon
     */
    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);

        float angle = getAngleFromColor(getPickerColor());
        Point p = getPointOnWheel(angle);

        Paint thumbPaint = mState == State.START ? mThumbPaintStart : mThumbPaintInside;
        canvas.drawCircle(p.x, p.y, mThumbRadius, thumbPaint);

        mCenterCirclePaint.setColor(getPickerColor());
        canvas.drawCircle(mCenterX, mCenterY,mCenterCircleRadius, mCenterCirclePaint);
    }

    /**
     * Called when this view should assign a size and position to all of its children.
     * @param changed This is a new size or position for this view
     * @param left Left position, relative to parent
     * @param top Top position, relative to parent
     * @param right Right position, relative to parent
     * @param bottom Bottom position, relative to parent
     */
    @Override
    public void onLayout(boolean changed, int left, int top, int right, int bottom) {
        super.onLayout(changed, left, top, right, bottom);

        mRadius = Math.min(getHeight(), getWidth()) / 2.0f;
        mCenterX = getWidth() / 2.0f;
        mCenterY = getHeight() / 2.0f;

        mThumbRadius = mRadius * RADIUS_TO_THUMB_RATIO;
        mCenterCircleRadius = mRadius - (2 * mThumbRadius);
    }

    /**
     * Calculate the essential geometry given an event.
     *
     * @param event Motion event to compute geometry for, most likely a touch.
     * @return EssentialGeometry value.
     */
    @Override
    protected EssentialGeometry essentialGeometry(MotionEvent event) {
        double x = Math.pow((event.getX() - mCenterX), 2);
        double y = Math.pow((event.getY() - mCenterY), 2);
        double dist = Math.sqrt(x + y);

        return dist <= mRadius ? EssentialGeometry.INSIDE : EssentialGeometry.OUTSIDE;
    }

    /* ****************************************************************************************** *
     *                               <Helper Functions />
     * ****************************************************************************************** */
    /**
     * Converts an angle on the wheel to a color.
     *
     * @param angle Position on the wheel in radians.
     * @return Color corresponding to that position as RGB.
     * @see #getTouchAngle(float, float)
     */
    @ColorInt
    public static int getColorFromAngle(double angle) {
        float hue = ((float) Math.toDegrees(angle) + 360 + 90) % 360;
        return Color.HSVToColor(new float[]{ hue, 1f, 1f });
    }

    /***
     * SOLN ONLY
     *
     * Calculate a position on the wheel from the angle. This will be used to
     * position the thumb properly regardless of where the user touches, by putting it
     * on the circumference of the wheel along the line from the user's finger to the center
     * of the wheel.
     * @param angle the angle (in radians)
     * @return cartesian coordinates of point on wheel
     */
    private Point getPointOnWheel(float angle) {
        double onCircleX = Math.cos(angle) * (mRadius - mThumbRadius);
        double onCircleY = Math.sin(angle) * (mRadius - mThumbRadius);

        onCircleX += mCenterX;
        onCircleY += mCenterY;

        return new Point((int) onCircleX, (int) onCircleY);
    }

    /**
     * Converts from a color to angle on the wheel.
     *
     * @param color RGB color as integer.
     * @return Position of this color on the wheel in radians.
     * @see #getTouchAngle(float, float)
     */
    public static float getAngleFromColor(int color) {
        float[] HSL = new float[3];
        ColorUtils.colorToHSL(color, HSL);
        return (float) Math.toRadians(HSL[0] - 90f);
    }

    /***
     * Calculate the angle of the selection on color wheel given a touch.
     *
     * @param touchX Horizontal position of the touch event.
     * @param touchY Vertical position of the touch event.
     * @return Angle of the touch, in radians.
     */
    protected float getTouchAngle(float touchX, float touchY) {
        // NOTE: This function REQUIRES that you properly use mCenterX, mCenterY, etc.

        // Assumes (for cardinal directions on the color wheel):
        // [ E => 0, South => Pi/2, W => -Pi, N => -Pi/2 ]

        return (float) Math.atan2(touchY - mCenterY, touchX - mCenterX);
    }
}
