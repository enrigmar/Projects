package cse340.undo.app.colorpicker;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.Shader;
import android.util.AttributeSet;
import android.view.MotionEvent;

import java.util.*;

import cse340.undo.R;

// Thanks to Charles I (21sp) for allowing us to use their solution

/**
 * This is a subclass of AbstractColorPickerView, that is, this View implements a ColorPicker.
 *
 * There are several class fields, enums, callback classes, and helper functions which have
 * been implemented for you.
 *
 * PLEASE READ AbstractColorPickerView.java to learn about these.
 */

public class SliderColorPickerView extends ColorPickerView {

    /**
     * Update the local model (color) for this colorpicker view
     *
     * @param x The x location that the user selected
     * @param y The y location that the user selected
     */
    protected void updateModel(float x, float y) {
        float thumbOffset = Math.max(mThumbTopTop, Math.min(y, mThumbTopTop + mThumbRange));
        setPickerColor(getChangedColor(mCurrentPickerColor, mCurrentZone,
                (int) ((1 - (thumbOffset - mThumbTopTop) / mThumbRange) * 255 )));
    }

    /* ********************************************************************************************** *
     *                               <End of model declarations />
     * ********************************************************************************************** */

    private static final float SLIDERS_AREA_HEIGHT_PROPORTION = .7f,
    SLIDERS_AREA_WIDTH_PROPORTION = .8f, SLIDER_HEIGHT_PROPORTION = .9f,
            SLIDER_WIDTH_PROPORTION = .1f, THUMB_HEIGHT_PROPORTION = .05f,
            THUMB_WIDTH_FACTOR = 1.5f;

    private LinearGradient mRedGradient, mGreenGradient, mBlueGradient;

    private final RectF mSlidersArea, mColorArea, mRedSelection, mGreenSelection, mBlueSelection,
                mRedThumb, mGreenThumb, mBlueThumb;

    private final Map<Primary, RectF> mThumbs;

    private float mThumbHeight, mThumbTopTop, mThumbRange, mRedGreenBorder, mGreenBlueBorder;

    private final Paint mBrush;

    private enum Primary{RED, GREEN, BLUE}

    private Primary mCurrentZone;
    /* ********************************************************************************************** *
     *                               <End of other fields and constants declarations />
     * ********************************************************************************************** */

    /**
     *
     * Constructor of the ColorPicker View
     * @param context The Context the view is running in, through which it can access the current theme, resources, etc.
     * @param attrs The attributes of the XML tag that is inflating the view. This value may be null.
     */
    public SliderColorPickerView(Context context, AttributeSet attrs) {
        super(context, attrs);
        setImageResource(R.drawable.color_wheel);
        mBrush = new Paint();

        // Initializes the rectangles for each element of the view
        mColorArea = new RectF();
        mSlidersArea = new RectF();
        mRedSelection = new RectF();
        mBlueSelection = new RectF();
        mGreenSelection = new RectF();
        mRedThumb = new RectF();
        mGreenThumb = new RectF();
        mBlueThumb = new RectF();

        mThumbs = new HashMap<>();
        mThumbs.put(Primary.RED, mRedThumb);
        mThumbs.put(Primary.GREEN, mGreenThumb);
        mThumbs.put(Primary.BLUE, mBlueThumb);
    }

    /**
     * Draw the ColorPicker on the Canvas
     * @param canvas the canvas that is drawn upon
     */
    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        // Draws outer rectangle which shows current picker color, and the rectangle housing sliders
        mBrush.setColor(mCurrentPickerColor);
        mBrush.setAlpha(255);
        canvas.drawRect(mColorArea, mBrush);
        mBrush.setColor(Color.GRAY);
        canvas.drawRect(mSlidersArea, mBrush);

        // Draws each RGB slider, using respective gradients
        mBrush.setShader(mRedGradient);
        mBrush.setColor(Color.RED);
        canvas.drawRect(mRedSelection, mBrush);
        mBrush.setShader(mGreenGradient);
        mBrush.setColor(Color.GREEN);
        canvas.drawRect(mGreenSelection, mBrush);
        mBrush.setShader(mBlueGradient);
        mBrush.setColor(Color.BLUE);
        canvas.drawRect(mBlueSelection, mBrush);

        mBrush.setColor(Color.WHITE);
        mBrush.setShader(null);

        // Draws each thumb at y-coordinates based on the current picker color
        for (Primary primary: mThumbs.keySet()) {
            RectF thumb = mThumbs.get(primary);
            if (mState == State.SELECTING && mCurrentZone == primary) {
                mBrush.setAlpha(127);
            } else {
                mBrush.setAlpha(255);
            }
            float thumbStart = (1 - (getPrimaryValue(mCurrentPickerColor, primary) / 255f))
                    * mThumbRange;
            thumb.top = mThumbTopTop + thumbStart;
            thumb.bottom = thumb.top + mThumbHeight;
            canvas.drawRect(thumb, mBrush);
        }
    }


    /* ****************************************************************************************** *
     *                               <Helper Functions />
     * ****************************************************************************************** */

    @Override
    // Determines which color slider to move (if any), which color to display, and when to send
    // color updates
    public boolean onTouchEvent(MotionEvent event) {
        EssentialGeometry geometry = essentialGeometry(event);
        switch (mState) {
            case START:
                if (event.getAction() == MotionEvent.ACTION_DOWN
                        && geometry == EssentialGeometry.INSIDE) {
                    mState = State.SELECTING;

                    // The only change to the method. Uses the x-coordinate of the initial touch
                    // to determine if the red, green, or blue slider should be moved
                    updateSelectedPrimary(event.getX());

                    updateModel(event.getX(), event.getY());
                    return true;
                }
                return false;
            case SELECTING:
                if (event.getAction() == MotionEvent.ACTION_MOVE
                        && geometry == EssentialGeometry.INSIDE) {
                    updateModel(event.getX(), event.getY());
                } else if (event.getAction() == MotionEvent.ACTION_UP) {
                    invokeColorChangeListeners(mCurrentPickerColor);
                    mState = State.START;
                    invalidate();
                }
                return true;
            default:
                return false;
        }
    }

    @Override
    // Returns INSIDE if the event's location is inside the view's bounding box, OUTSIDE otherwise
    protected EssentialGeometry essentialGeometry(MotionEvent event) {
        if (mColorArea.contains(event.getX(), event.getY())) {
            return EssentialGeometry.INSIDE;
        }
        return EssentialGeometry.OUTSIDE;
    }

    // Uses the given x-coordinate to determine which color slider should be selected and moved
    private void updateSelectedPrimary(float xCoordinate) {
        if (xCoordinate < mRedGreenBorder) {
            mCurrentZone = Primary.RED;
        } else if (xCoordinate < mGreenBlueBorder) {
            mCurrentZone = Primary.GREEN;
        } else {
            mCurrentZone = Primary.BLUE;
        }
    }

    @Override
    // Lays out each element of the view, including current color shower, slider container,
    // sliders, and (partially) slider thumbs
    protected void onLayout(boolean changed, int left, int top, int right, int bottom) {
        super.onLayout(changed, left, top, right, bottom);
        if (changed) {
            // Initializes layout measurements
            float height = bottom - top;
            float width = right - left;
            float widthMargin = (1 - SLIDERS_AREA_WIDTH_PROPORTION) * width / 2;
            float heightMargin = (1 - SLIDERS_AREA_HEIGHT_PROPORTION) * height / 2;
            float selectionHeightMargin = (1 - SLIDERS_AREA_HEIGHT_PROPORTION
                    * SLIDER_HEIGHT_PROPORTION) * height / 2;

            // Sets location of each element
            initMainRects(height, width, heightMargin, widthMargin);
            initSliderRects(height, width, widthMargin, selectionHeightMargin);
            initGradients();

            // Initializes thumb layout measurements to be used in onDraw
            mThumbHeight = height * SLIDERS_AREA_HEIGHT_PROPORTION * THUMB_HEIGHT_PROPORTION;
            mThumbTopTop = selectionHeightMargin - mThumbHeight / 2;
            mThumbRange = height * SLIDERS_AREA_HEIGHT_PROPORTION * SLIDER_HEIGHT_PROPORTION;
        }
    }

    // Lays out the rectangle showing the selected color and the one that houses the RGB sliders
    private void initMainRects(float height, float width, float heightMargin, float widthMargin) {
        mColorArea.set(0, 0, width, height);
        mSlidersArea.set(widthMargin, heightMargin, width - widthMargin,
                height - heightMargin);
    }

    // Lays out the rectangles that act as "RGB sliders": showing which thumb position
    // corresponds to which RGB color level; also initializes "borders" defining which slider moves
    // when the screen is touched; also partially lays out the thumbs for each slider
    private void initSliderRects(float height, float width, float widthMargin,
                                 float selectionHeightMargin) {
        // Initializes measurement variables for defining where sliders go
        float spacerWidth = width * SLIDERS_AREA_WIDTH_PROPORTION
                * (1 - 3 * SLIDER_WIDTH_PROPORTION) / 4;
        float selectionAreaWidth = width * SLIDERS_AREA_WIDTH_PROPORTION
                * SLIDER_WIDTH_PROPORTION;
        float thumbOffset = selectionAreaWidth * (THUMB_WIDTH_FACTOR - 1) / 2;
        float thumbWidth = selectionAreaWidth * THUMB_WIDTH_FACTOR;
        float start = widthMargin + spacerWidth;

        // Sets slider locations and thumb x-coordinates based on those measurements
        mRedSelection.set(start, selectionHeightMargin, start + selectionAreaWidth,
                height - selectionHeightMargin);
        mRedThumb.set(start - thumbOffset, 0, start - thumbOffset + thumbWidth,
                0);
        start += selectionAreaWidth + spacerWidth;
        mRedGreenBorder = start - spacerWidth / 2;
        mGreenSelection.set(start, selectionHeightMargin, start + selectionAreaWidth,
                height - selectionHeightMargin);
        mGreenThumb.set(start - thumbOffset, 0, start - thumbOffset + thumbWidth,
                0);
        start += selectionAreaWidth + spacerWidth;
        mGreenBlueBorder = start - spacerWidth / 2;
        mBlueSelection.set(start, selectionHeightMargin, start + selectionAreaWidth,
                height - selectionHeightMargin);
        mBlueThumb.set(start - thumbOffset, 0, start - thumbOffset + thumbWidth,
                0);
    }

    // Creates RGB-to-black gradients, to denote which slider controls which RGB color level
    private void initGradients() {
        mRedGradient = new LinearGradient(0f, mRedSelection.top, 0f,
                mRedSelection.bottom, Color.RED, Color.BLACK, Shader.TileMode.CLAMP);
        mGreenGradient = new LinearGradient(0f, mGreenSelection.top, 0f,
                mGreenSelection.bottom, Color.GREEN, Color.BLACK, Shader.TileMode.CLAMP);
        mBlueGradient = new LinearGradient(0f, mBlueSelection.top, 0f,
                mBlueSelection.bottom, Color.BLUE, Color.BLACK, Shader.TileMode.CLAMP);
    }

    // Takes a given color and returns a version of that color, where one of its RGB primary values
    // (given) is changed to a given new level
    private static int getChangedColor(int original, Primary colorToChange, int newLevel) {
        int red = Color.red(original), green = Color.green(original), blue = Color.blue(original);
        switch (colorToChange) {
            case RED:
                red = newLevel;
                break;
            case GREEN:
                green = newLevel;
                break;
            case BLUE:
                blue = newLevel;
                break;
        }
        return Color.rgb(red, green, blue);
    }

    // Returns the given primary value of the given RGB color
    private static int getPrimaryValue(int color, Primary rgbToGet) {
        switch (rgbToGet) {
            case RED:
                return Color.red(color);
            case GREEN:
                return Color.green(color);
            case BLUE:
                return Color.blue(color);
        }
        return -1;
    }
}
