package cse340.undo.app.colorpicker;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.support.v4.graphics.ColorUtils;

// Thanks to Henry H (21wi) for allowing us to use their solution

/**
 * This is a subclass of AbstractColorPickerView, that is, this View implements a ColorPicker.
 *
 * There are several class fields, enums, callback classes, and helper functions which have
 * been implemented for you.
 *
 * PLEASE READ AbstractColorPickerView.java to learn about these.
 */
/**
 * A rectangular luminance-hue-based color picker.
 */
public class GradientColorPickerView extends ColorPickerView {

    /**
     * Update the local model (color) for this colorpicker view
     *
     * @param x The x location that the user selected
     * @param y The y location that the user selected
     */
    protected void updateModel(float x, float y) {
        float[] HSL = new float[3];

        // Transform (x, y) in the view -> (x, y) in the picker.
        int pickerWidth = getPickerWidth();
        int pickerHeight = getPickerHeight();

        float pickerX = getPickerX();
        float pickerY = getPickerY();

        x -= pickerX;
        y -= pickerY;

        // Clamp (x, y) to a region just inside the picker.
        x = Math.min(Math.max(x, PICKER_BORDER_SIZE), pickerWidth - PICKER_BORDER_SIZE);
        y = Math.min(Math.max(y, PICKER_BORDER_SIZE), pickerHeight - PICKER_BORDER_SIZE);

        // Convert (x, y) into a color.
        HSL[0] = x * 360.0f / pickerWidth;
        HSL[1] = COLOR_SATURATION;
        HSL[2] = y / pickerHeight;

        setPickerColor(ColorUtils.HSLToColor(HSL));
    }

    /**
     * @param event Motion event to compute geometry for, most likely a touch.
     * @return geometry for the given event (e.g. INSIDE if inside)
     */
    @Override
    protected EssentialGeometry essentialGeometry(MotionEvent event) {
        float x = event.getX();
        float y = event.getY();

        boolean inside = isPointInPicker(x, y) || isPointInThumb(x, y);

        return inside ? EssentialGeometry.INSIDE : EssentialGeometry.OUTSIDE;
    }

    /* ****************************************************************************************** *
     *                               <End of model declarations />
     * ****************************************************************************************** */

    private final Paint mThumbOutlinePaint;
    private final Paint mThumbPaint;

    // color & NO_ALPHA_MASK sets the alpha channel of the given color to zero.
    private static final int NO_ALPHA_MASK = 0x00ffffff;

    // The outline color of the thumb, and its fill color when in the start state.
    private static final int THUMB_OUTLINE_COLOR = 0xaacccccc; // Slightly transparent, light gray

    // Ratio that defines the size of the thumb.
    private static final float THUMB_RADIUS_TO_SELF_WIDTH_RATIO = 0.05f;

    // Defines the outline of the thumb
    private static final float THUMB_OUTLINE_RADIUS_TO_INNER_RADIUS_RATIO = 1.1f;

    // Size of region just inside picker we can't drag thumb's center into (prevents
    //  ambiguous colors, so prevents thumb from jumping)
    private static final int PICKER_BORDER_SIZE = 12;

    // The saturation of the colors we can select using the picker.
    private static final float COLOR_SATURATION = 1.0f;

    /* ****************************************************************************************** *
     *                          <End of other fields and constants declarations />
     * ****************************************************************************************** */

    /**
     * Constructor of the ColorPicker View
     *
     * @param context The Context the view is running in, through which it can access the current
     *                theme, resources, etc.
     * @param attrs   The attributes of the XML tag that is inflating the view. This value may be
     *                null.
     */
    public GradientColorPickerView(Context context, AttributeSet attrs) {
        super(context, attrs);

        mThumbOutlinePaint = new Paint();
        mThumbOutlinePaint.setColor(THUMB_OUTLINE_COLOR);

        mThumbPaint = new Paint();
        mThumbPaint.setAlpha(255); // Completely opaque
    }

    /**
     * Draw the ColorPicker on the Canvas
     *
     * @param canvas the canvas that is drawn upon
     */
    @Override
    protected void onDraw(final Canvas canvas) {
        super.onDraw(canvas);

        drawThumb(canvas);
    }

    @Override
    public void onLayout(boolean changed, int left, int top, int right, int bottom) {
        super.onLayout(changed, left, top, right, bottom);

        if (changed) {
            int viewWidth = right - left;
            int viewHeight = bottom - top;

            int pickerWidth = getPickerWidth(viewWidth),
                    pickerHeight = getPickerHeight(viewHeight);

            setImageBitmap(generateBackground(viewWidth, viewHeight, pickerWidth, pickerHeight));
        }
    }


    /*
    * ******************************************************************************************* *
     *                               <Helper Functions />
     * ****************************************************************************************** */
    private void drawThumb(final Canvas canvas) {
        float thumbX, thumbY;
        float thumbRadius, thumbOutlineRadius;

        if (mState == State.SELECTING) {  /// ???
            mThumbPaint.setColor(mCurrentPickerColor);
        } else {
            mThumbPaint.setColor(THUMB_OUTLINE_COLOR);
        }

        thumbX = getThumbX();
        thumbY = getThumbY();

        thumbRadius = THUMB_RADIUS_TO_SELF_WIDTH_RATIO * getWidth();
        thumbOutlineRadius = thumbRadius * THUMB_OUTLINE_RADIUS_TO_INNER_RADIUS_RATIO;

        canvas.drawCircle(thumbX, thumbY, thumbOutlineRadius, mThumbOutlinePaint);
        canvas.drawCircle(thumbX, thumbY, thumbRadius, mThumbPaint);
    }

    /**
     * Get the width of the picker in the view.
     *
     * @param fullWidth The full width of the view.
     * @return the width of the picker region of the view.
     */
    private int getPickerWidth(final int fullWidth) {
        return (int) (fullWidth - getThumbRadius() * 2);
    }

    /**
     * @return the width of the picker in this view
     */
    private int getPickerWidth() {
        return getPickerWidth(getWidth());
    }

    /**
     * Get the height of the picker portion of the view.
     *
     * @param fullHeight The height of the view.
     * @return the height of the picker.
     */
    private int getPickerHeight(final int fullHeight) {
        return (int) (fullHeight - getThumbRadius() * 2);
    }

    /**
     * @return the width of the picker in this view
     */
    private int getPickerHeight() {
        return getPickerHeight(getHeight());
    }

    /**
     * Get the x-position of the picker in a view
     *
     * @param pickerWidth the width of the picker
     * @param fullWidth   the width of the view
     * @return the x-coordinate of the position of the picker in the
     * view with given parameters.
     */
    private static int getPickerX(final int pickerWidth, final int fullWidth) {
        return (fullWidth - pickerWidth) / 2;
    }

    /**
     * @return the x-position of the picker in **this** view.
     */
    private int getPickerX() {
        return getPickerX(getPickerWidth(), getWidth());
    }

    /**
     * Get the y-position of the picker in a view
     *
     * @param pickerHeight the width of the picker
     * @param fullHeight   the width of the view
     * @return the y-coordinate of the position of the picker in the
     * view with given parameters.
     */
    private static int getPickerY(final int pickerHeight, final int fullHeight) {
        return (fullHeight - pickerHeight) / 2;
    }

    /**
     * @return the y-position of the picker in **this** view.
     */
    private int getPickerY() {
        return getPickerY(getPickerHeight(), getHeight());
    }

    /**
     * @return the radius of the thumb in this.
     */
    private float getThumbRadius() {
        return getWidth() * THUMB_RADIUS_TO_SELF_WIDTH_RATIO;
    }

    /**
     * @return the x-coordinate of the position of the thumb relative to this.
     */
    private float getThumbX() {
        float[] HSL = new float[3];
        ColorUtils.colorToHSL(mCurrentPickerColor, HSL);

        return HSL[0] / 360.0f * getPickerWidth() + getPickerX();
    }

    /**
     * @return the y-coordinate of the position of the thumb relative to this.
     */
    private float getThumbY() {
        float[] HSL = new float[3];
        ColorUtils.colorToHSL(mCurrentPickerColor, HSL);

        return HSL[2] * getPickerHeight() + getPickerY();
    }

    /**
     * Get whether the point (x, y) is in this view's picker.
     * @param x the x-coordinate of the point to test; 0 is the left edge of this view
     * @param y the y-coordinate of the point to test; 0 is the top edge of this view
     * @return whether (x, y) \in this view's picker
     */
    private boolean isPointInPicker(float x, float y)  {
        float pickerStartX = getPickerX();
        float pickerStartY = getPickerY();

        float pickerStopX = getPickerWidth() + pickerStartX;
        float pickerStopY = getPickerHeight() + pickerStartY;

        return x > pickerStartX && y > pickerStartY && y < pickerStopY && x < pickerStopX;
    }

    /**
     * Get whether the point (in view coordinates) is in this' thumb.
     * @param x is the x-coordinate of the point to test
     * @param y is the y-coordinate of the point to test
     * @return whether the provided point is in this' thumb.
     */
    private boolean isPointInThumb(float x, float y) {
        float dx = getThumbX() - x;
        float dy = getThumbY() - y;

        float thumbRadius = getThumbRadius();

        float distanceSquared = dx * dx + dy * dy;
        return distanceSquared <= thumbRadius * thumbRadius;
    }

    /**
     * Generate a viewWidth x viewHeight background for the picker.
     *
     * @param viewWidth the width of the view in pixels.
     * @param viewHeight the height of the view in pixels.
     * @param pickerWidth the width of the picker in pixels.
     * @param pickerHeight the height of the picker in pixels.
     * @return a bitmap containing the color picker's background.
     */
    private static Bitmap generateBackground(final int viewWidth, final int viewHeight,
                                             final int pickerWidth, final int pickerHeight) {
        int[] colors = new int[viewWidth * viewHeight];

        int pickerX = getPickerX(pickerWidth, viewWidth);
        int pickerY = getPickerY(pickerHeight, viewHeight);

        for (int x = 0; x < viewWidth; x++) {
            int xDistToPicker = 0, yDistToPicker = 0;

            // Determine the x-offset from the picker's edge (if we're outside the picker)
            if (x < pickerX) {
                xDistToPicker = pickerX - x;
            } else if (x > pickerWidth + pickerX) {
                xDistToPicker = x - pickerWidth - pickerX;
            }

            for (int y = 0; y < viewHeight; y++) {
                // Determine the y-offset to the picker's edge
                if (y < pickerY) {
                    yDistToPicker = pickerY - y;
                } else if (y > pickerWidth + pickerY) {
                    yDistToPicker = y - pickerHeight - pickerY;
                }

                // Determine the color of the current pixel
                float[] HSL = new float[] {
                        (float) x / viewWidth * 360.0f,
                        COLOR_SATURATION,
                        (float) y / viewHeight
                };

                int alpha = 255;

                // Base the transparency of the current pixel on how close we
                // are to being in the picker. If we're in the picker, xDistToPicker
                // and yDistToPicker are both zero.
                alpha -= xDistToPicker * 255 / pickerX;
                alpha -= yDistToPicker * 255 / pickerY;

                alpha = Math.max(alpha, 0);

                colors[x + viewWidth * y] =
                        ColorUtils.HSLToColor(HSL) & NO_ALPHA_MASK | (alpha << 24);

            }
        }

        // Ref: https://developer.android.com/reference/android/graphics/Bitmap#createBitmap(int[],
        // %20int,%20int,%20android.graphics.Bitmap.Config)
        return Bitmap.createBitmap(colors, viewWidth, viewHeight, Bitmap.Config.ARGB_8888);
    }
}
